function generateQR() {
    const text = document.getElementById('textInput').value.trim();
    if (text !== '') {
      const qrCodeElement = document.getElementById('qrCode');
      qrCodeElement.innerHTML = '';
  
      const qrImg = document.createElement('img');
      qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(text)}&size=200x200`;
  
      qrCodeElement.appendChild(qrImg);
    }
  }
  